import streamlit as st
import pandas as pd
import os
from src.report_generator import generate_excel_report_from_df
st.set_page_config(page_title="Auto Excel Report", layout="centered")

st.title("📊 Auto Excel Report Generator")

uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)

    st.subheader("Preview Data")
    st.dataframe(df.head())

    if st.button("Generate Excel Report"):
        report_path = generate_excel_report_from_df(df)

        with open(report_path, "rb") as f:
            st.download_button(
                label="⬇ Download Excel Report",
                data=f,
                file_name=os.path.basename(report_path),
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
