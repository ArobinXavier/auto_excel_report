def detect_columns(df):
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    categorical_cols = df.select_dtypes(include="object").columns.tolist()
    return numeric_cols, categorical_cols


def group_data(df, num_col, cat_col):
    return df.groupby(cat_col)[num_col].sum()