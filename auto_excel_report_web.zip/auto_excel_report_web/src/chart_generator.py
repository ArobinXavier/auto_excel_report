import matplotlib.pyplot as plt

def create_chart(series, title, filename):
    plt.figure()
    series.plot(kind="bar")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()