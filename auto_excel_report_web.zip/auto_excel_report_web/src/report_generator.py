import os
from datetime import datetime
from openpyxl import Workbook
from openpyxl.drawing.image import Image

from .analyzer import detect_columns, group_data
from .chart_generator import create_chart

REPORT_PATH = "reports/"


def generate_excel_report_from_df(df):
    numeric_cols, categorical_cols = detect_columns(df)

    os.makedirs(REPORT_PATH, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Auto Report"

    row_pointer = 1
    chart_y = 5

    for num_col in numeric_cols:
        total_value = df[num_col].sum()
        ws[f"A{row_pointer}"] = f"Total {num_col}"
        ws[f"B{row_pointer}"] = total_value
        row_pointer += 2

        for cat_col in categorical_cols:
            grouped = group_data(df, num_col, cat_col)

            ws[f"A{row_pointer}"] = f"{num_col} by {cat_col}"
            row_pointer += 1

            for k, v in grouped.items():
                ws[f"A{row_pointer}"] = k
                ws[f"B{row_pointer}"] = v
                row_pointer += 1

            row_pointer += 1

            chart_file = f"{REPORT_PATH}{num_col}_{cat_col}.png"
            create_chart(grouped, f"{num_col} by {cat_col}", chart_file)

            ws.add_image(Image(chart_file), f"D{chart_y}")
            chart_y += 15

        row_pointer += 2

    report_name = f"auto_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    report_file = REPORT_PATH + report_name
    wb.save(report_file)

    return report_file
